//
//  ForecastCell.swift
//  
//
//  Created by FanYu on 6/26/15.
//
//

import UIKit

class ForecastCell: UITableViewCell {
    @IBOutlet weak var iDay: UILabel!
    @IBOutlet weak var iTemperatureLow: UILabel!
    @IBOutlet weak var iCondition: UILabel!
    @IBOutlet weak var iTemperatureHigh: UILabel!
}
