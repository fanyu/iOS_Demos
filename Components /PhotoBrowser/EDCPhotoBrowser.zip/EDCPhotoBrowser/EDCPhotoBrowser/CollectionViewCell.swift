//
//  CollectionViewCell.swift
//  EDCPhotoBrowser
//
//  Created by FanYu on 26/10/2015.
//  Copyright © 2015 FanYu. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    
}
