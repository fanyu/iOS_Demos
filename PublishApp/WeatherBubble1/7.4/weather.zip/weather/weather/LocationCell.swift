//
//  LocationCell.swift
//  
//
//  Created by FanYu on 6/17/15.
//
//

import UIKit

class LocationCell: UITableViewCell {
    
    @IBOutlet weak var iCity: UILabel!
    @IBOutlet weak var iTemp: UILabel!
    @IBOutlet weak var iCondition: UILabel!    
}
